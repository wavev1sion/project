import sys
import sqlite3

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QTableWidget, QTableWidgetItem
from PyQt5.QtChart import QChart, QChartView, QPieSeries, QPieSlice
from PyQt5.QtGui import QPainter, QFont
from PyQt5.QtCore import Qt

CURRENCIES = {
    'RUB': 1,
    'USD': 60.98,
    'EUR': 60.82,
    'CNY': 8.37
}


# Конвертер валют
class Conversion(QMainWindow):
    def __init__(self, name):
        super().__init__()
        uic.loadUi('Design\Conversion.ui', self)
        self.name = name
        self.initUI()

    def initUI(self):
        # Добавление типов валют
        self.Input_type.addItems(CURRENCIES)
        self.Output_type.addItems(CURRENCIES)
        # Обработка нажатия кнопки
        self.Konvert.clicked.connect(self.converting)
        # Возвращение
        self.Back.clicked.connect(self.back)

    def converting(self):
        # Проверка поля
        if self.Input_currency.text() == '':
            self.label.setText('Введите сумму для конвертации')
            self.Output_currency.setText('')
        else:
            self.label.setText('')
            try:
                self.Output_currency.setText(
                    f'{float(self.Input_currency.text()) * CURRENCIES[self.Input_type.currentText()] / CURRENCIES[self.Output_type.currentText()]:.2f}')
            except:
                self.label.setText('Введите сумму для конвертации')

    def back(self):
        # Возвращение
        self.profile_window = Profile(self.name)
        self.profile_window.show()
        self.close()


# Просмотр подробной статистики
class Stats(QMainWindow):
    def __init__(self, name):
        super().__init__()
        uic.loadUi('Design\Statistics.ui', self)
        self.name = name
        self.initUI()

    def initUI(self):
        # Подключение к БД
        con = sqlite3.connect("Databases\Expenses.sqlite")

        # Создание курсора
        cur = con.cursor()

        # Поиск всех подходящих строк
        self.result = {}
        data = cur.execute(
            """SELECT name, tipe, cost FROM users_expenses""").fetchall()
        for i in data:
            if i[0] == self.name:
                if i[1] in self.result:
                    self.result[i[1]] += i[2]
                else:
                    self.result[i[1]] = i[2]
        self.result = sorted([[j, self.result[j]]
                             for j in self.result], key=lambda arg: arg[1], reverse=True)

        con.close()

        # Создание таблицы
        self.Expenses_table = QTableWidget(self)
        self.Expenses_table.setFont(QFont('Sitka', 14))
        self.Expenses_table.move(100, 30)
        self.Expenses_table.resize(500, 300)
        # Названия колонок
        self.Expenses_table.setColumnCount(2)
        self.Expenses_table.setHorizontalHeaderLabels(
            ["Категория", "Стоимость"])
        # Количество строк
        self.Expenses_table.setRowCount(len(self.result))
        # Ширина колонок
        self.Expenses_table.setColumnWidth(0, 249)
        self.Expenses_table.setColumnWidth(1, 249)
        # Заполнение строк
        for i in range(len(self.result)):
            self.Expenses_table.setItem(
                i, 0, QTableWidgetItem(self.result[i][0]))
            self.Expenses_table.setItem(
                i, 1, QTableWidgetItem(str(self.result[i][1])))
        # Кастомизация таблиицы
        self.Expenses_table.setStyleSheet(
            "color: #FFFFFF; background-color: #007BA7")
        self.Expenses_table.setEditTriggers(QTableWidget.NoEditTriggers)
        stylesheet = "::section{Background-color: #1E213D}"
        self.Expenses_table.horizontalHeader().setStyleSheet(stylesheet)
        self.Expenses_table.horizontalHeader().setFont(QFont('Sitka', 14))
        self.Expenses_table.verticalHeader().setVisible(False)

        # Возвращение в профиль
        self.Back.clicked.connect(self.back)

    def back(self):
        # Возвращение
        self.profile_window = Profile(self.name)
        self.profile_window.show()
        self.close()


# Добавление расходов
class Add_exps(QMainWindow):
    def __init__(self, name):
        super().__init__()
        uic.loadUi('Design\Adding.ui', self)
        self.name = name
        # Нажатие кнопки добавления траты
        self.Add_button.clicked.connect(self.add_exp)
        # Нажатие кнопки возвращения к профилю
        self.Back.clicked.connect(self.back)

    def check(self):
        if self.Expenses_name.text() == '':
            self.res_wnd.setText('Введите название товара или услуги')
            return False
        elif self.Expenses_tipe.text() == '':
            self.res_wnd.setText('Введите тип товара или услуги')
            return False
        elif self.Expenses_cost.text() == '':
            self.res_wnd.setText('Введите стоимость товара или услуги')
            return False
        else:
            return True

    def add_exp(self):
        if self.check():
            # Подключение к БД
            con = sqlite3.connect("Databases\Expenses.sqlite")

            # Создание курсора
            cur = con.cursor()

            # Добавление расхода в БД
            try:
                id0 = int(sorted(
                    [item[0] for item in cur.execute("""SELECT id FROM users_expenses""").fetchall()])[-1]) + 1
            except:
                id0 = 0
            data = (id0, self.name,
                    self.Expenses_tipe.text(), self.Expenses_name.text(), self.Expenses_cost.text())

            cur.execute(
                "INSERT INTO users_expenses VALUES (?, ?, ?, ?, ?);", data)
            con.commit()

            # Вывод результата
            self.res_wnd.setText('Трата успешно добавлена')

            con.close()

    def back(self):
        # Возвращение
        self.profile_window = Profile(self.name)
        self.profile_window.show()
        self.close()


# Окно профиля
class Profile(QMainWindow):
    def __init__(self, name):
        self.name = name
        super().__init__()
        uic.loadUi('Design\Profile.ui', self)
        self.initUI()

    def create_piechart(self):
        # Куски диаграммы
        series = QPieSeries()
        for i in sorted([[j, self.result[j]] for j in self.result], key=lambda arg: arg[1]):
            series.append(i[0], i[1])

        total = sum([self.result[i] for i in self.result])
        for i in range(len(series)):
            # adding slice
            slice = QPieSlice()
            slice = series.slices()[i]
            slice.setLabel(str(round(sorted(
                [[j, self.result[j]] for j in self.result], key=lambda arg: arg[1])[i][1] / total * 100, 2)) + '%')
            slice.setLabelVisible(True)
            slice.setLabelFont(QFont('Arial', 14))

        # Создание диаграммы
        chart = QChart()
        # Тема диаграммы
        chart.setTheme(0)
        # Добавление частей
        chart.addSeries(series)
        chart.createDefaultAxes()
        # Вывод названий первых четырёх категорий
        for i in range(len(series)):
            chart.legend().markers(series)[i].setLabel(
                sorted([[j, self.result[j]] for j in self.result], key=lambda arg: arg[1])[i][0])

        for i in range(len(series) - 4):
            chart.legend().markers(series)[i].setVisible(False)
        # Анимация
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.setAnimationDuration(2500)
        # Заголовок
        chart.setTitle("Ваши расходы")
        # Пустой фон
        chart.setBackgroundVisible(False)
        # Смена расположения легенды
        chart.legend().setAlignment(Qt.AlignBottom)
        # Изменение шрифтов заголовка и легенды
        chart.setTitleFont(QFont('Arial', 16))
        chart.legend().setFont(QFont('Arial', 16))

        chartview = QChartView(chart)
        chartview.setRenderHint(QPainter.Antialiasing)

        self.horizontalLayout.addWidget(chartview)

    def initUI(self):
        # Проверка расходов
        # Подключение к БД
        con = sqlite3.connect("Databases\Expenses.sqlite")

        # Создание курсора
        cur = con.cursor()

        # Выполнение запроса и получение всех результатов
        names = [item[0] for item in cur.execute(
            """SELECT name FROM users_expenses""").fetchall()]
        if self.name in names:
            self.result = {}
            data = cur.execute(
                """SELECT name, tipe, cost FROM users_expenses""").fetchall()
            for i in data:
                if i[0] == self.name:
                    if i[1] in self.result:
                        self.result[i[1]] += i[2]
                    else:
                        self.result[i[1]] = i[2]

            # Создание диаграммы
            self.create_piechart()
        else:
            # Отсутствие трат
            self.label = QLabel()
            self.label.setText('На даннный момент у Вас нет расходов')
            self.label.setStyleSheet('QLabel {color:  #007BA7}')
            self.label.setFont(QFont('Sitka', 24))
            self.horizontalLayout.addWidget(self.label)
            self.label.setAlignment(Qt.AlignCenter)

        # Выход из профиля
        self.Exit.clicked.connect(self.exit)

        # Добавление траты
        self.Add_expenses.clicked.connect(self.add)

        # Подробная статистика
        self.Show_statistics.clicked.connect(self.show_stats)

        # Конвертер
        self.Converter.clicked.connect(self.show_converter)

    def exit(self):
        # Выход из аккаунта
        self.authorization_window = Authorization()
        self.authorization_window.show()
        self.close()

    def add(self):
        # Добавление траты
        self.adding_window = Add_exps(self.name)
        self.adding_window.show()
        self.close()

    def show_stats(self):
        # Подробная статистика
        self.statistic_window = Stats(self.name)
        self.statistic_window.show()
        self.close()

    def show_converter(self):
        # Конвертер
        self.conversion_window = Conversion(self.name)
        self.conversion_window.show()
        self.close()


# Окно авторизации
class Authorization(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('Design\Authorization.ui', self)
        self.initUI()

    def initUI(self):
        # Подпись окон
        self.Login.setPlaceholderText('Login')
        self.Password.setPlaceholderText('Password')

        # Реакция кнопки регистрации
        self.Registration.clicked.connect(self.reg)

        # Реакция кнопки входа
        self.Enter.clicked.connect(self.entering)

    def reg_check(self):
        # Проверка на невведённый логин
        if self.Login.text() == '':
            # Проверка на невведённый пароль
            if self.Password.text() == '':
                self.Result.setText('Введите логин и пароль')
                return False
            else:
                self.Result.setText('Введите логин')
                return False
        else:
            # Проверка на невведённый пароль
            if self.Password.text() == '':
                self.Result.setText('Введите пароль')
                return False
            else:
                # Проверка на совпадающие логины
                # Подключение к БД
                con = sqlite3.connect("Databases\Accounts.sqlite")

                # Создание курсора
                cur = con.cursor()

                # Выполнение запроса и получение всех результатов
                result = [item[0] for item in cur.execute(
                    """SELECT users.name FROM users""").fetchall()]

                # Поиск совпадений
                if self.Login.text() in result:
                    self.Result.setText('Имя пользователя уже занято')
                    con.close()
                    return False
                else:
                    con.close()
                    return True

    def enter_check(self):
        # Проверка на невведённый логин
        if self.Login.text() == '':
            # Проверка на невведённый пароль
            if self.Password.text() == '':
                self.Result.setText('Введите логин и пароль')
                return False
            else:
                self.Result.setText('Введите логин')
                return False
        else:
            # Проверка на невведённый пароль
            if self.Password.text() == '':
                self.Result.setText('Введите пароль')
                return False
            else:
                # Проверка на наличие аккаунта и совпадение пароля

                # Подключение к БД
                con = sqlite3.connect("Databases\Accounts.sqlite")

                # Создание курсора
                cur = con.cursor()

                # Выполнение запроса и получение всех результатов
                result = [item[0] for item in cur.execute(
                    """SELECT users.name FROM users""").fetchall()]

                # Проверка на наличие аккаунта
                if self.Login.text() in result:
                    # Проверка на совпадение пароля
                    names = [item[0] for item in cur.execute(
                        "SELECT users.name FROM users").fetchall()]
                    password = [item[0] for item in cur.execute(
                        "SELECT users.password FROM users").fetchall()]

                    accounts = {}
                    for i in range(len(names)):
                        accounts[names[i]] = password[i]

                    if accounts[self.Login.text()] == self.Password.text():
                        return True
                    else:
                        self.Result.setText('Некорректный пароль')
                        return False
                else:
                    self.Result.setText('Некорректный логин')
                    return False

    def reg(self):
        # Проверка на пустые поля и повторы
        if self.reg_check():
            # Подключение к БД
            con = sqlite3.connect("Databases\Accounts.sqlite")

            # Создание курсора
            cur = con.cursor()

            # Добавление пользователя
            try:
                id0 = int(sorted(
                    [item[0] for item in cur.execute("""SELECT id FROM users""").fetchall()])[-1]) + 1
            except:
                id0 = 0
            data = (id0, self.Login.text(), self.Password.text())

            cur.execute(
                "INSERT INTO users VALUES (?, ?, ?);", data)
            con.commit()

            # Вывод результата
            self.Result.setText('Аккаунт успешно зарегистрирован')

            # Окно профиля
            self.profile_window = Profile(self.Login.text())
            self.profile_window.show()
            self.close()

    def entering(self):
        if self.enter_check():
            # Окно профиля
            self.profile_window = Profile(self.Login.text())
            self.profile_window.show()
            self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Authorization()
    ex.show()
    sys.exit(app.exec_())
